/// Flyer Chat File Message package. Provides a widget for file messages.
library;

export 'src/flyer_chat_file_message.dart';
