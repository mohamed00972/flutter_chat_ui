/// Flyer Chat System Message package. Provides a widget for system messages.
library;

export 'src/flyer_chat_system_message.dart';
