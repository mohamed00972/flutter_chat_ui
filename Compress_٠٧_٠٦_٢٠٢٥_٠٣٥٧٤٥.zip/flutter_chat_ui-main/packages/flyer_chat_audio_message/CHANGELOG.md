## 0.0.12

- Version bump to match other packages

## 0.0.11

- Version bump to match other packages

## 0.0.10

- Version bump to match other packages

## 0.0.9

- Version bump to match other packages

## 0.0.8

- Version bump to match other packages

## 0.0.7

- Require Flutter 3.29 and Dart 3.7

## 0.0.6

- Version bump to match other packages

## 0.0.5

- Version bump to match other packages

## 0.0.4

- Version bump to match other packages

## 0.0.3

- Version bump to match other packages

## 0.0.1

- Initial release
